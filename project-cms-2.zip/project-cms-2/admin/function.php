<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js" integrity="sha512-AA1Bzp5Q0K1KanKKmvN/4d3IRKVlv9PYgwFPvm32nPO6QS8yH1HO7LbgB1pgiOxPtfeg5zEn2ba64MUcqJx6CA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<?php 

    session_start();
    function Connection(){
        $connection = new mysqli('127.0.0.1','root','','db_final_project_2_5');

        return $connection;
    }
    
    function Register(){
        if(isset($_POST['btn_register'])){
            // echo 124;
            $username = $_POST['username'];
            $email    = $_POST['email'];
            $password = $_POST['password'];
            $profile  = $_FILES['profile']['name'];
            
            // echo $username.$email.$password.$profile;

            if(!empty($username) && !empty($email) && !empty($password) && !empty($profile)){
                $profile = rand(1,9999).'-'.$profile;
                $path = './assets/Profile/'.$profile;
                move_uploaded_file($_FILES['profile']['tmp_name'],$path);

                $password = md5($password);

                $sql = "INSERT INTO `tbl_user`(`username`,`email`,`password`,`profile`)
                    VALUES('$username','$email','$password','$profile')";

                $rs = Connection()->query($sql);
                if($rs){
                    header('location:login.php');
                }
            }
            else{
                echo '
                        <script>
                            $(document).ready(function(){
                                swal({
                                    title: "Error",
                                    text: "You missed some field",
                                    icon: "error",
                                    button: "Done",
                                  });
                            });
                        </script>
                    ';
            }
            
        }
    }
    Register();

    function Login(){
        if(isset($_POST['btn_login'])){
            $nameEmail = $_POST['name_email'];
            $password  = $_POST['password']; 

            // echo $nameEmail.$password;

            if(!empty($nameEmail) && !empty($password)){

                $password = md5($password);

                $sql = "SELECT * FROM `tbl_user` 
                        WHERE (`username` = '$nameEmail' OR `email` = '$nameEmail') AND `password` = '$password'";
                
                $rs = Connection()->query($sql);
                $row = mysqli_fetch_assoc($rs);
                
                if(!empty($row)){
                    $_SESSION['user'] = $row['id'];
                    header('location:index.php');
                }else{
                    echo '
                    <script>
                        $(document).ready(function(){
                            swal({
                                title: "Error",
                                text: "Wrong Username or Email or Password",
                                icon: "error",
                                button: "Done",
                              });
                        });
                    </script>
                ';
                }
            }
            else{
                echo '
                        <script>
                            $(document).ready(function(){
                                swal({
                                    title: "Error",
                                    text: "You missed some field",
                                    icon: "error",
                                    button: "Done",
                                  });
                            });
                        </script>
                    ';
            }
        }
    }
    Login();

    function Logout(){
        if(isset($_POST['btn-logout'])){
            // echo 123;
            unset($_SESSION['user']);
        }
    }
    Logout();

    function AddLogo(){
        if(isset($_POST['btn-add-logo'])){
            // echo 123;
            $status = $_POST['status'];
            $thumbnail = $_FILES['thumbnail']['name'];
            // echo $status.$thumbnail;
            if(!empty($status) && !empty($thumbnail)){
                $thumbnail = date('dmyhis').'-'.$thumbnail;
                $path = './assets/Logo/'.$thumbnail;
                move_uploaded_file($_FILES['thumbnail']['tmp_name'],$path);
                $sql = "INSERT INTO `tbl_logo`(`status`,`thumbnail`) VALUES('$status','$thumbnail')";
                $rs = Connection()->query($sql);
                if($rs){
                    echo '
                    <script>
                        $(document).ready(function(){
                            swal({
                                title: "Success",
                                text: "Logo Insert Success",
                                icon: "success",
                                button: "Done",
                              });
                        });
                    </script>
                '; 
                }
            }
            else{
                echo '
                    <script>
                        $(document).ready(function(){
                            swal({
                                title: "Error",
                                text: "You missed some field",
                                icon: "error",
                                button: "Done",
                              });
                        });
                    </script>
                ';
            }

        }
    }
    AddLogo();

    function ViewLogo(){
        $sql = "SELECT * FROM `tbl_logo`";
        $rs  = Connection()->query($sql);
        while($row = mysqli_fetch_assoc($rs)){
            echo '
                <tr>
                    <td><img src="./assets/Logo/'.$row['thumbnail'].'" width="100px"/></td>
                    <td>'.$row['status'].'</td>
                    <td>'.$row['post_date'].'</td>
                    <td width="150px">
                        <a href="update-logo.php?id='.$row['id'].'" class="btn btn-primary">Update</a>
                        <button type="button" remove-id="'.$row['id'].'" class="btn btn-danger btn-remove" data-bs-toggle="modal" data-bs-target="#exampleModal">
                            Remove
                        </button>
                    </td>
                </tr>
            
            ';
        } 
    }

    function UpdateLogo(){
        if(isset($_POST['btn-update-logo'])){
            // echo 123;
            $id = $_GET['id'];
            $status = $_POST['status'];
            $thumbnail = $_FILES['thumbnail']['name'];  

            if(empty($thumbnail)){
                $thumbnail = $_POST['old_thumbnail'];
            }
            else{
                $thumbnail = date('dmyhis').'-'.$thumbnail;
                $path = './assets/Logo/'.$thumbnail;
                move_uploaded_file($_FILES['thumbnail']['tmp_name'],$path);
            }

            if(!empty($status)){
                $sql = "UPDATE `tbl_logo` SET `status`='$status' , `thumbnail`='$thumbnail' WHERE `id` = '$id'";
                $rs = Connection()->query($sql);
                if($rs){
                    echo '
                    <script>
                        $(document).ready(function(){
                            swal({
                                title: "Success",
                                text: "Logo Update Success",
                                icon: "success",
                                button: "Done",
                              });
                        });
                    </script>
                '; 
                }
            }
        }
    }
    UpdateLogo();

    function DeleteLogo(){
        if(isset($_POST['btn-delete-logo'])){
            // echo 123;
            $id = $_POST['remove_id'];

            $sql = "DELETE FROM `tbl_logo` WHERE `id` = '$id'";
            $rs  = Connection()->query($sql);
            if($rs){
                echo '
                <script>
                    $(document).ready(function(){
                        swal({
                            title: "Success",
                            text: "Logo Delete Success",
                            icon: "success",
                            button: "Done",
                          });
                    });
                </script>
            '; 
            }
        }
    }
    DeleteLogo();