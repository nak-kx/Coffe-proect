<?php 
    include('sidebar.php');
?>
                <div class="col-10">
                    <div class="content-right">
                        <div class="top">
                            <h3>Logout</h3>
                        </div>
                        <div class="bottom">
                            <h1>Are you sure that you want to logout ?</h1>
                            <form method="post">
                                <button name="btn-logout" class="btn btn-success my-2">Yes</button>
                                <a href="index.php" class="btn btn-danger my-2 rounded-0">No</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</body>
</html>